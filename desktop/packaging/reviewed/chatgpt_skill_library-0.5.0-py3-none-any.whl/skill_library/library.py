from __future__ import annotations

import json
import os
import re
import shutil
import tempfile
import threading
from dataclasses import asdict, dataclass
from pathlib import Path

from .parser import ParsedSkill, SkillValidationError, parse_skill
from .source import SkillSource

SKILL_PATH_RE = re.compile(r"^skills/([a-z0-9]+(?:-[a-z0-9]+)*)/SKILL\.md$")
SKILL_SUBTREE_RE = re.compile(r"^skills/([^/]+)/(.+)$")


@dataclass(frozen=True)
class SkillSummary:
    name: str
    description: str
    metadata: dict[str, str]
    sha256: str


def _terms(text: str) -> set[str]:
    text = text.lower()
    english = set(re.findall(r"[a-z0-9]+", text))
    cjk_chunks = re.findall(r"[\u3400-\u9fff]+", text)
    cjk: set[str] = set()
    for chunk in cjk_chunks:
        if len(chunk) == 1:
            cjk.add(chunk)
        else:
            cjk.update(chunk[i : i + 2] for i in range(len(chunk) - 1))
            if len(chunk) >= 3:
                cjk.update(chunk[i : i + 3] for i in range(len(chunk) - 2))
    return english | cjk


class SkillLibrary:
    def __init__(self, data_dir: Path | str | None = None):
        if data_dir is None:
            configured = os.getenv("SKILL_LIBRARY_DATA_DIR")
            data_dir = Path(configured) if configured else Path.home() / ".cache" / "chatgpt-skill-library"
        self.data_dir = Path(data_dir)
        self.snapshots_dir = self.data_dir / "snapshots"
        self.state_path = self.data_dir / "state.json"
        self._lock = threading.RLock()
        self._content_cache: dict[tuple[str, str], str] = {}
        self._catalog_cache: tuple[str, dict] | None = None
        self._search_index_cache: tuple[str, list[tuple[dict, set[str], str]]] | None = None

    def _state(self) -> dict:
        if not self.state_path.exists():
            return {}
        return json.loads(self.state_path.read_text(encoding="utf-8"))

    def current_sha(self) -> str | None:
        return self._state().get("commit_sha")

    def _snapshot_dir(self, sha: str) -> Path:
        return self.snapshots_dir / sha

    def _catalog(self) -> dict:
        sha = self.current_sha()
        if not sha:
            return {"commit_sha": None, "skills": []}
        if self._catalog_cache and self._catalog_cache[0] == sha:
            return self._catalog_cache[1]
        path = self._snapshot_dir(sha) / "catalog.json"
        if not path.exists():
            raise RuntimeError("active snapshot is missing catalog.json")
        catalog = json.loads(path.read_text(encoding="utf-8"))
        self._catalog_cache = (sha, catalog)
        return catalog

    def _search_index(self) -> list[tuple[dict, set[str], str]]:
        sha = self.current_sha()
        if not sha:
            return []
        if self._search_index_cache and self._search_index_cache[0] == sha:
            return self._search_index_cache[1]
        rows: list[tuple[dict, set[str], str]] = []
        for item in self._catalog().get("skills", []):
            metadata = item.get("metadata") or {}
            haystack = " ".join(
                [
                    item["name"],
                    item["description"],
                    " ".join(f"{k} {v}" for k, v in metadata.items()),
                ]
            )
            rows.append((item, _terms(haystack), str(metadata.get("tags", "")).lower()))
        self._search_index_cache = (sha, rows)
        return rows

    def list_skills(self) -> dict:
        catalog = self._catalog()
        return {
            "commit_sha": catalog.get("commit_sha"),
            "skills": catalog.get("skills", []),
        }

    def search_skills(self, query: str, limit: int = 5) -> dict:
        if not query.strip():
            raise ValueError("query must not be empty")
        limit = max(1, min(int(limit), 20))
        query_terms = _terms(query)
        rows = []
        for item, candidate_terms, tags in self._search_index():
            overlap = len(query_terms & candidate_terms)
            coverage = overlap / max(1, len(query_terms))
            name_bonus = 0.15 if query.lower() in item["name"].lower() else 0.0
            tag_bonus = 0.1 if query.lower() in tags else 0.0
            score = min(1.0, coverage + name_bonus + tag_bonus)
            if score > 0:
                rows.append({**item, "score": round(score, 4)})
        rows.sort(key=lambda row: (-row["score"], row["name"]))
        return {"commit_sha": self.current_sha(), "matches": rows[:limit]}

    def read_skill(self, name: str) -> dict:
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name):
            raise ValueError("invalid skill name")
        sha = self.current_sha()
        if not sha:
            raise RuntimeError("skill library has no cached snapshot; run refresh_library")
        catalog = self._catalog()
        if not any(item["name"] == name for item in catalog.get("skills", [])):
            raise KeyError(f"unknown skill: {name}")
        cache_key = (sha, name)
        if cache_key not in self._content_cache:
            path = self._snapshot_dir(sha) / "skills" / name / "SKILL.md"
            self._content_cache[cache_key] = path.read_text(encoding="utf-8")
        return {
            "name": name,
            "commit_sha": sha,
            "content": self._content_cache[cache_key],
        }

    def refresh(self, source: SkillSource, force: bool = False) -> dict:
        with self._lock:
            remote_sha = source.get_head_sha()
            current_sha = self.current_sha()
            if current_sha == remote_sha and not force:
                return {
                    "status": "unchanged",
                    "commit_sha": current_sha,
                    "skill_count": len(self._catalog().get("skills", [])),
                }

            files = source.list_files(remote_sha)
            skill_paths = sorted(path for path in files if SKILL_PATH_RE.fullmatch(path))
            unsupported = [
                path
                for path in files
                if SKILL_SUBTREE_RE.fullmatch(path) and not SKILL_PATH_RE.fullmatch(path)
            ]
            if unsupported:
                raise SkillValidationError(
                    "v0.1 is text-only; unsupported skill files: " + ", ".join(unsupported[:10])
                )
            if not skill_paths:
                raise SkillValidationError("repository contains no skills/*/SKILL.md files")

            parsed: list[ParsedSkill] = []
            seen: set[str] = set()
            for path in skill_paths:
                skill = parse_skill(source.read_text(path, remote_sha), path)
                if skill.name in seen:
                    raise SkillValidationError(f"duplicate skill name: {skill.name}")
                seen.add(skill.name)
                parsed.append(skill)

            self.data_dir.mkdir(parents=True, exist_ok=True)
            self.snapshots_dir.mkdir(parents=True, exist_ok=True)
            final_dir = self._snapshot_dir(remote_sha)
            if not final_dir.exists():
                staging = Path(tempfile.mkdtemp(prefix="snapshot-", dir=self.data_dir))
                try:
                    for skill in parsed:
                        target = staging / "skills" / skill.name / "SKILL.md"
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_text(skill.content, encoding="utf-8")
                    catalog = {
                        "commit_sha": remote_sha,
                        "skills": [
                            asdict(
                                SkillSummary(
                                    name=skill.name,
                                    description=skill.description,
                                    metadata=skill.metadata,
                                    sha256=skill.sha256,
                                )
                            )
                            for skill in parsed
                        ],
                    }
                    (staging / "catalog.json").write_text(
                        json.dumps(catalog, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8",
                    )
                    os.replace(staging, final_dir)
                except Exception:
                    shutil.rmtree(staging, ignore_errors=True)
                    raise

            state_tmp = self.data_dir / "state.json.tmp"
            state_tmp.write_text(
                json.dumps({"commit_sha": remote_sha}, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
            os.replace(state_tmp, self.state_path)
            self._content_cache.clear()
            self._catalog_cache = None
            self._search_index_cache = None
            return {
                "status": "updated",
                "commit_sha": remote_sha,
                "previous_commit_sha": current_sha,
                "skill_count": len(parsed),
            }
