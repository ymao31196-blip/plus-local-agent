from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath

from .parser import NAME_RE
from .registry import safe_subdir
from .source import SkillSource

TEXT_SUFFIXES = {
    ".md", ".txt", ".json", ".yaml", ".yml", ".py", ".sh", ".ps1",
    ".csv", ".toml", ".xml", ".html", ".js", ".ts", ".sql",
}
MAX_FILES = 500
MAX_FILE_BYTES = 256 * 1024
MAX_TOTAL_BYTES = 8 * 1024 * 1024


def skill_name_from_folder(parts: tuple[str, ...]) -> str | None:
    """Recognize common repo skill layouts, without scanning arbitrary paths."""
    if len(parts) == 1:
        name = parts[0]  # <skill>/SKILL.md
    elif len(parts) == 2 and parts[0] == "skills":
        name = parts[1]  # skills/<skill>/SKILL.md
    elif len(parts) == 3 and (
        parts[:2] in (("skills", "categories"), (".agents", "skills"), ("agents", "skills"))
        or parts[0] == "skills"  # skills/<category>/<skill>/SKILL.md
    ):
        name = parts[2]
    else:
        return None
    return name if NAME_RE.fullmatch(name) else None


@dataclass
class ScopedSource:
    """Normalize common Skill layouts to skills/<name>/... for the snapshot layer."""
    source: SkillSource
    subdir: str = "."
    _path_map: dict[str, str] = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        self.subdir = safe_subdir(self.subdir)

    def get_head_sha(self) -> str:
        return self.source.get_head_sha()

    def list_files(self, ref: str) -> list[str]:
        prefix = "" if self.subdir == "." else self.subdir + "/"
        originals = [
            p for p in self.source.list_files(ref)
            if p.startswith(prefix) and "\\" not in p and "//" not in p
        ]
        folders: dict[str, str] = {}
        for full in originals:
            relative = full[len(prefix):]
            parts = tuple(relative.split("/"))
            if not parts or parts[-1] != "SKILL.md":
                continue
            name = skill_name_from_folder(parts[:-1])
            if name is None:
                continue
            folder = full[:-len("SKILL.md")]
            if name in folders:
                raise ValueError(f"duplicate skill name in source: {name}")
            folders[name] = folder

        mapping: dict[str, str] = {}
        for name, original_folder in folders.items():
            for full in originals:
                if not full.startswith(original_folder):
                    continue
                relative = full[len(original_folder):]
                if not relative or ".." in PurePosixPath(relative).parts:
                    continue
                target = f"skills/{name}/{relative}"
                if target in mapping:
                    raise ValueError(f"duplicate normalized skill path: {target}")
                mapping[target] = full
        self._path_map = mapping
        return sorted(mapping)

    def read_text(self, path: str, ref: str) -> str:
        if path not in self._path_map:
            raise KeyError(f"unlisted or invalid source resource: {path}")
        return self.source.read_text(self._path_map[path], ref)


@dataclass
class LocalDirectorySource:
    """Read-only captured local snapshot, bounded to administrator-approved roots."""
    path: Path
    allowed_roots: tuple[Path, ...]
    _contents: dict[str, str] = field(default_factory=dict, init=False)
    _sha: str | None = field(default=None, init=False)

    def _approved_path(self) -> Path:
        if not self.allowed_roots:
            raise PermissionError("local sources disabled: set SKILL_LIBRARY_LOCAL_ROOTS")
        raw = Path(self.path)
        if not raw.is_absolute() or not raw.is_dir():
            raise ValueError("local source must be an existing absolute directory")
        resolved = raw.resolve(strict=True)
        for allowed in self.allowed_roots:
            approved = Path(allowed).resolve(strict=True)
            if resolved == approved or approved in resolved.parents:
                # Reject symlink components within approved root.
                relative = raw.absolute().relative_to(approved)
                current = approved
                for part in relative.parts:
                    current = current / part
                    if current.is_symlink():
                        raise PermissionError("local source directory contains a symlink")
                return resolved
        raise PermissionError("local source is outside SKILL_LIBRARY_LOCAL_ROOTS")

    @staticmethod
    def _trees(root: Path) -> list[Path]:
        trees = []
        for rel in ("skills", ".agents/skills", "agents/skills"):
            candidate = root.joinpath(*rel.split("/"))
            if candidate.is_symlink() or candidate.parent.is_symlink():
                raise PermissionError("skill source tree contains a symlink")
            if candidate.is_dir():
                trees.append(candidate)
        # Direct children of a source can also be individual skill directories.
        for child in root.iterdir():
            if child.name.startswith("."):
                continue
            if child.is_symlink():
                if (child / "SKILL.md").exists():
                    raise PermissionError("skill directory symlinks are forbidden")
                continue
            if child.is_dir() and (child / "SKILL.md").is_file():
                trees.append(child)
        if not trees:
            raise ValueError("source must contain skills/, .agents/skills/ or <skill>/SKILL.md")
        return trees

    def get_head_sha(self) -> str:
        root = self._approved_path()
        contents: dict[str, str] = {}
        total = 0
        for tree in self._trees(root):
            for parent, dirs, files in os.walk(tree, followlinks=False):
                parent_path = Path(parent)
                depth = len(parent_path.relative_to(tree).parts)
                if depth > 4:
                    dirs.clear()
                    continue
                if parent_path.is_symlink():
                    raise PermissionError("symlink directories are not permitted")
                for directory in dirs:
                    if (parent_path / directory).is_symlink():
                        raise PermissionError("symlink directories are not permitted")
                for filename in files:
                    path = parent_path / filename
                    if path.is_symlink():
                        raise PermissionError("symlink files are not permitted")
                    if path.suffix.lower() not in TEXT_SUFFIXES:
                        continue
                    relative = path.relative_to(root).as_posix()
                    if relative in contents:
                        continue
                    if len(contents) >= MAX_FILES:
                        raise ValueError("too many text resources in local skill source")
                    size = path.stat().st_size
                    if size > MAX_FILE_BYTES or total + size > MAX_TOTAL_BYTES:
                        raise ValueError("local skill source exceeds resource size limits")
                    data = path.read_bytes()
                    total += len(data)
                    contents[relative] = data.decode("utf-8")
        digest = hashlib.sha256()
        for name in sorted(contents):
            digest.update(name.encode("utf-8") + b"\0")
            digest.update(contents[name].encode("utf-8") + b"\0")
        self._contents = contents
        self._sha = digest.hexdigest()
        return self._sha

    def list_files(self, ref: str) -> list[str]:
        if not self._sha or ref != self._sha:
            raise ValueError("source snapshot changed or was not initialized")
        return sorted(self._contents)

    def read_text(self, path: str, ref: str) -> str:
        if not self._sha or ref != self._sha:
            raise ValueError("source snapshot changed or was not initialized")
        return self._contents[path]
