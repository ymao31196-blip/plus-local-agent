"""GitHub-backed, cache-first Agent Skills library."""

__version__ = "0.1.1"
