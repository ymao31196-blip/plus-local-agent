from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
from dataclasses import asdict
from pathlib import Path, PurePosixPath

from .library import SKILL_PATH_RE, SkillLibrary, SkillSummary
from .local_source import (MAX_FILE_BYTES, MAX_FILES, MAX_TOTAL_BYTES, TEXT_SUFFIXES,
                           LocalDirectorySource, ScopedSource)
from .parser import SkillValidationError, parse_skill
from .source import SkillSource

RESOURCE_RE = re.compile(
    r"^skills/([a-z0-9]+(?:-[a-z0-9]+)*)/(references|scripts|assets)/(.+)$"
)
SKILL_NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
COMMIT_RE = re.compile(r"^[a-fA-F0-9]{40,64}$")


def safe_resource_path(path: str) -> str:
    if not isinstance(path, str) or "\\" in path or path.startswith("/"):
        raise ValueError("resource path must be relative and POSIX formatted")
    parts = PurePosixPath(path).parts
    if (len(parts) < 2 or parts[0] not in ("references", "scripts", "assets")
            or any(x in ("", ".", "..") or x.startswith(".") for x in path.split("/"))
            or Path(path).suffix.lower() not in TEXT_SUFFIXES):
        raise ValueError("resource path is not an allowed text resource")
    return "/".join(parts)


class ManagedSourceLibrary(SkillLibrary):
    """Per-source cache compatible with legacy SkillLibrary's search/read structure."""

    def refresh(self, source: SkillSource, force: bool = False) -> dict:
        with self._lock:
            sha = source.get_head_sha()
            if not isinstance(sha, str) or not COMMIT_RE.fullmatch(sha):
                raise SkillValidationError("source version must be a 40-64 character hex digest")
            previous = self.current_sha()
            if sha == previous and not force:
                return {
                    "status": "unchanged",
                    "commit_sha": sha,
                    "skill_count": len(self._catalog()["skills"]),
                    "invalid_skills": self._catalog().get("invalid_skills", []),
                }
            files = sorted(set(source.list_files(sha)))
            skill_paths = [p for p in files if SKILL_PATH_RE.fullmatch(p)]
            empty_local_source = (not skill_paths and isinstance(source, ScopedSource)
                                  and isinstance(source.source, LocalDirectorySource))
            if not skill_paths and not empty_local_source:
                raise SkillValidationError("source must contain skills/<name>/SKILL.md")
            if len(skill_paths) > 128:
                raise SkillValidationError("too many skills (limit 128)")
            parsed = {}
            invalid_skills = []
            for path in skill_paths:
                try:
                    skill = parse_skill(source.read_text(path, sha), path, allow_extensions=True)
                except SkillValidationError as exc:
                    invalid_skills.append({"path": path, "error": str(exc)})
                    continue
                if skill.name in parsed:
                    raise SkillValidationError(f"duplicate skill: {skill.name}")
                parsed[skill.name] = skill
            if not parsed and not empty_local_source:
                raise SkillValidationError("source contains no valid skills; " +
                                           str(invalid_skills[:3]))

            resources: dict[str, tuple[str, bytes]] = {}
            total_bytes = sum(len(skill.content.encode("utf-8")) for skill in parsed.values())
            for path in files:
                match = RESOURCE_RE.fullmatch(path)
                if not match or match[1] not in parsed:
                    continue
                if PurePosixPath(path).suffix.lower() not in TEXT_SUFFIXES:
                    continue  # binary assets and unknown extensions are not text resources
                rel = safe_resource_path(path[len("skills/" + match[1] + "/"):])
                if len(resources) >= MAX_FILES:
                    raise SkillValidationError("too many text resources")
                value = source.read_text(path, sha)
                data = value.encode("utf-8")
                if len(data) > MAX_FILE_BYTES or total_bytes + len(data) > MAX_TOTAL_BYTES:
                    raise SkillValidationError("resource size limit exceeded")
                total_bytes += len(data)
                resources[path] = (rel, data)

            catalog = {"commit_sha": sha, "skills": [], "invalid_skills": invalid_skills}
            for skill in parsed.values():
                entry = asdict(SkillSummary(
                    name=skill.name, description=skill.description,
                    metadata=skill.metadata, sha256=skill.sha256,
                ))
                entry["resources"] = [
                    {"path": relative, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
                    for path, (relative, data) in resources.items()
                    if path.startswith(f"skills/{skill.name}/")
                ]
                catalog["skills"].append(entry)

            self.data_dir.mkdir(parents=True, exist_ok=True)
            self.snapshots_dir.mkdir(parents=True, exist_ok=True)
            target = self._snapshot_dir(sha)
            if not target.exists():
                staging = Path(tempfile.mkdtemp(prefix=".skill-stage-", dir=self.data_dir))
                try:
                    for skill in parsed.values():
                        item = staging / "skills" / skill.name / "SKILL.md"
                        item.parent.mkdir(parents=True, exist_ok=True)
                        item.write_text(skill.content, encoding="utf-8")
                    for path, (_, data) in resources.items():
                        item = staging / Path(path)
                        item.parent.mkdir(parents=True, exist_ok=True)
                        item.write_bytes(data)
                    (staging / "catalog.json").write_text(
                        json.dumps(catalog, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8",
                    )
                    os.replace(staging, target)
                except Exception:
                    shutil.rmtree(staging, ignore_errors=True)
                    raise
            # Never expose a half-refreshed snapshot. Point to it only when ready.
            state_tmp = self.data_dir / "state.json.tmp"
            state_tmp.write_text(json.dumps({"commit_sha": sha}) + "\n", encoding="utf-8")
            os.replace(state_tmp, self.state_path)
            self._content_cache.clear()
            self._catalog_cache = None
            self._search_index_cache = None
            return {"status": "updated", "commit_sha": sha,
                    "previous_commit_sha": previous, "skill_count": len(parsed),
                    "invalid_skills": invalid_skills}

    def read_skill(self, name: str) -> dict:
        result = super().read_skill(name)
        item = next((row for row in self._catalog()["skills"] if row["name"] == name), None)
        if item is None or hashlib.sha256(result["content"].encode("utf-8")).hexdigest() != item["sha256"]:
            raise RuntimeError("skill snapshot integrity check failed")
        return result

    def read_resource(self, name: str, resource_path: str) -> dict:
        if not SKILL_NAME_RE.fullmatch(name):
            raise ValueError("invalid skill name")
        relative = safe_resource_path(resource_path)
        catalog = self._catalog()
        item = next((row for row in catalog["skills"] if row["name"] == name), None)
        if item is None:
            raise KeyError(f"unknown skill: {name}")
        metadata = next((row for row in item.get("resources", []) if row["path"] == relative), None)
        if metadata is None:
            raise KeyError(f"unknown resource: {relative}")
        sha = self.current_sha()
        if sha is None:
            raise RuntimeError("no cached source snapshot")
        path = self._snapshot_dir(sha) / "skills" / name / Path(relative)
        # Snapshot paths were generated from sanitized names and trusted staging.
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != metadata["sha256"]:
            raise RuntimeError("resource snapshot integrity check failed")
        return {"name": name, "path": relative, "commit_sha": sha,
                "sha256": metadata["sha256"], "content": raw.decode("utf-8")}
