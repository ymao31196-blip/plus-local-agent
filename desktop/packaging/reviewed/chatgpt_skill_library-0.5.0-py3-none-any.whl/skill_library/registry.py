from __future__ import annotations

import json
import os
import re
import tempfile
import threading
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath

ID_RE = re.compile(r"^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$")
REPO_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9-]*/[A-Za-z0-9_.-]+$")
BRANCH_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_./-]*$")
PART_RE = re.compile(r"^(?:\.[A-Za-z0-9_][A-Za-z0-9_.-]*|[A-Za-z0-9_][A-Za-z0-9_.-]*)$")


def safe_subdir(value: str) -> str:
    if value in ("", "."):
        return "."
    if not isinstance(value, str) or "\\" in value or value.startswith("/"):
        raise ValueError("subdir must be a relative POSIX directory")
    parts = value.split("/")
    if any(p in ("", ".", "..") or not PART_RE.fullmatch(p) for p in parts):
        raise ValueError("invalid subdir (dot segments and traversal are forbidden)")
    return "/".join(parts)


@dataclass(frozen=True)
class SourceConfig:
    id: str
    kind: str
    location: str
    branch: str = "main"
    subdir: str = "."
    enabled: bool = True
    priority: int = 0

    def __post_init__(self) -> None:
        if not isinstance(self.id, str) or not ID_RE.fullmatch(self.id) or len(self.id) > 60:
            raise ValueError("source id must be a short lowercase hyphenated name")
        if self.kind not in ("github", "git", "local"):
            raise ValueError("source kind must be github, git, or local")
        if not isinstance(self.location, str) or not self.location.strip():
            raise ValueError("source location is required")
        if self.kind in ("github", "git"):
            if not REPO_RE.fullmatch(self.location) or ".." in self.location.split("/")[1]:
                raise ValueError("GitHub location must be owner/repo")
        else:
            if not Path(self.location).is_absolute():
                raise ValueError("local source location must be an absolute path")
        if not isinstance(self.branch, str) or not BRANCH_RE.fullmatch(self.branch) or ".." in self.branch:
            raise ValueError("invalid branch")
        object.__setattr__(self, "subdir", safe_subdir(self.subdir))
        if not isinstance(self.enabled, bool):
            raise ValueError("enabled must be boolean")
        if type(self.priority) is not int or abs(self.priority) > 1000:
            raise ValueError("priority must be an integer within ±1000")


class SourceRegistry:
    """Local single-user registry. Never persist access tokens or credentials."""

    def __init__(self, data_dir: str | Path):
        self.data_dir = Path(data_dir)
        self.path = self.data_dir / "sources.json"
        self._lock = threading.RLock()

    def list(self) -> list[SourceConfig]:
        with self._lock:
            if not self.path.exists():
                return []
            payload = json.loads(self.path.read_text(encoding="utf-8"))
            if payload.get("version") != 1 or not isinstance(payload.get("sources"), list):
                raise ValueError("unsupported or corrupt source registry")
            sources = [SourceConfig(**row) for row in payload["sources"]]
            if len({source.id for source in sources}) != len(sources):
                raise ValueError("duplicate source IDs in registry")
            return sorted(sources, key=lambda x: (-x.priority, x.id))

    def get(self, source_id: str) -> SourceConfig:
        return next((s for s in self.list() if s.id == source_id), None) or self._missing(source_id)

    @staticmethod
    def _missing(source_id: str) -> SourceConfig:
        raise KeyError(f"unknown source: {source_id}")

    def _save(self, sources: list[SourceConfig]) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        payload = {"version": 1, "sources": [asdict(s) for s in sources]}
        fd, tmp_name = tempfile.mkstemp(prefix=".sources-", suffix=".tmp", dir=self.data_dir)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(payload, stream, indent=2, ensure_ascii=False)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(tmp_name, self.path)
        finally:
            if os.path.exists(tmp_name):
                os.unlink(tmp_name)

    def add(self, config: SourceConfig) -> dict:
        with self._lock:
            items = self.list()
            if any(s.id == config.id for s in items):
                raise ValueError(f"source id already exists: {config.id}")
            self._save([*items, config])
            return asdict(config)

    def update(self, source_id: str, *, enabled: bool | None = None,
               priority: int | None = None) -> dict:
        with self._lock:
            items = self.list()
            old = self.get(source_id)
            updated = SourceConfig(**{
                **asdict(old),
                "enabled": old.enabled if enabled is None else enabled,
                "priority": old.priority if priority is None else priority,
            })
            self._save([updated if s.id == source_id else s for s in items])
            return asdict(updated)

    def remove(self, source_id: str) -> dict:
        with self._lock:
            old = self.get(source_id)
            self._save([s for s in self.list() if s.id != source_id])
            return asdict(old)
