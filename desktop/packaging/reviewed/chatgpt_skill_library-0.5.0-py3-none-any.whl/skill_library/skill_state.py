"""Single-instance per-skill enabled state, separate from source contents."""
from __future__ import annotations

import json
import os
import tempfile
import threading
from pathlib import Path

from .parser import NAME_RE
from .registry import ID_RE


class SkillStates:
    def __init__(self, data_dir: Path):
        self.path = Path(data_dir) / "skill-states.json"
        self.lock = threading.RLock()

    def _load(self) -> dict[str, list[str]]:
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if data.get("version") != 1 or not isinstance(data.get("disabled"), dict):
            raise ValueError("invalid skill state registry")
        result = data["disabled"]
        if any(not ID_RE.fullmatch(s) or not isinstance(names, list)
               or any(not isinstance(n, str) or not NAME_RE.fullmatch(n) for n in names)
               for s, names in result.items()):
            raise ValueError("invalid skill state entries")
        return result

    def enabled(self, source_id: str, name: str) -> bool:
        with self.lock:
            return name not in self._load().get(source_id, [])

    def _save(self, data: dict[str, list[str]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix=".skill-states-", suffix=".tmp", dir=self.path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump({"version": 1, "disabled": data}, stream, sort_keys=True)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(tmp, self.path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)

    def set_enabled(self, source_id: str, name: str, enabled: bool) -> None:
        if type(enabled) is not bool or not ID_RE.fullmatch(source_id) or not NAME_RE.fullmatch(name):
            raise ValueError("invalid Skill state update")
        with self.lock:
            data = self._load()
            existing = set(data.get(source_id, []))
            if enabled:
                existing.discard(name)
            else:
                existing.add(name)
            if existing:
                data[source_id] = sorted(existing)
            else:
                data.pop(source_id, None)
            self._save(data)

    def forget_source(self, source_id: str) -> None:
        with self.lock:
            data = self._load()
            if source_id in data:
                del data[source_id]
                self._save(data)

    def rename(self, source_id: str, old: str, new: str) -> None:
        with self.lock:
            data = self._load()
            existing = set(data.get(source_id, []))
            if old in existing:
                existing.discard(old)
                existing.add(new)
                data[source_id] = sorted(existing)
                self._save(data)

    def forget_skill(self, source_id: str, name: str) -> None:
        with self.lock:
            data = self._load()
            existing = set(data.get(source_id, []))
            if name in existing:
                existing.remove(name)
                if existing:
                    data[source_id] = sorted(existing)
                else:
                    data.pop(source_id, None)
                self._save(data)
