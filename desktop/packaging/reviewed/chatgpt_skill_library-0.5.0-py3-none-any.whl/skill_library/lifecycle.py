"""Preview/confirm lifecycle operations on individually approved local Skill folders.

Deletion moves a skill into the instance's recoverable trash, not permanent
erasure. Neither operation invokes git or executes untrusted Skill resources.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import uuid
from pathlib import Path

from .authoring import SkillAuthor, DRAFT_ID_RE, HASH_RE
from .parser import NAME_RE, parse_skill

MAX_FILES = 500
MAX_TOTAL_BYTES = 8 * 1024 * 1024


class SkillLifecycle:
    def __init__(self, manager, write_roots=None):
        self.manager = manager
        self.author = SkillAuthor(manager, write_roots=write_roots)
        self.plans_dir = manager.data_dir / "lifecycle-plans"
        self.trash_dir = manager.data_dir / "skill-trash"

    @staticmethod
    def _inventory(folder: Path) -> tuple[list[dict], str]:
        if folder.is_symlink() or not folder.is_dir():
            raise ValueError("Skill folder must be an ordinary directory")
        rows = []
        total = 0
        for parent, dirs, files in os.walk(folder, followlinks=False):
            base = Path(parent)
            if base.is_symlink():
                raise PermissionError("symlinked Skill directories are forbidden")
            for d in dirs:
                if (base / d).is_symlink():
                    raise PermissionError("symlinked Skill directories are forbidden")
            for file in files:
                path = base / file
                if path.is_symlink() or not path.is_file():
                    raise PermissionError("non-regular Skill files are forbidden")
                total += path.stat().st_size
                if len(rows) >= MAX_FILES or total > MAX_TOTAL_BYTES:
                    raise ValueError("Skill folder exceeds lifecycle limits")
                rows.append({
                    "path": path.relative_to(folder).as_posix(),
                    "bytes": path.stat().st_size,
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                })
        rows.sort(key=lambda row: row["path"])
        if not any(row["path"] == "SKILL.md" for row in rows):
            raise ValueError("Skill folder requires SKILL.md")
        digest = hashlib.sha256(json.dumps(rows, sort_keys=True).encode("utf-8")).hexdigest()
        return rows, digest

    @staticmethod
    def _renamed_skill(content: str, old_name: str, new_name: str) -> str:
        end = content.find("\n---\n", 4)
        if not content.startswith("---\n") or end < 0:
            raise ValueError("invalid Skill frontmatter")
        header, body = content[:end], content[end:]
        pattern = re.compile(r"(?m)^name\s*:\s*[^\n]+$")
        if len(pattern.findall(header)) != 1:
            raise ValueError("expected exactly one top-level name frontmatter field")
        new_content = pattern.sub(f"name: {new_name}", header, count=1) + body
        parse_skill(new_content, f"skills/{new_name}/SKILL.md", allow_extensions=True)
        return new_content

    def prepare(self, action: str, source_id: str, name: str,
                new_name: str | None = None) -> dict:
        if action not in ("delete", "rename"):
            raise ValueError("action must be delete or rename")
        if not NAME_RE.fullmatch(name):
            raise ValueError("invalid Skill name")
        if action == "rename" and (not isinstance(new_name, str)
                                    or not NAME_RE.fullmatch(new_name)
                                    or new_name == name):
            raise ValueError("rename requires a different valid new_name")
        if action == "delete" and new_name is not None:
            raise ValueError("delete must not supply new_name")
        target = self.author._destination(source_id, name)
        if not target.exists():
            raise FileNotFoundError(f"unknown local Skill: {name}")
        folder = target.parent
        rows, digest = self._inventory(folder)
        if action == "rename":
            dest = self.author._destination(source_id, new_name)
            if dest.parent.exists():
                raise FileExistsError(f"target Skill name already exists: {new_name}")
            self._renamed_skill(target.read_text(encoding="utf-8"), name, new_name)
        plan_id = uuid.uuid4().hex
        record = {
            "plan_id": plan_id, "action": action, "source_id": source_id,
            "name": name, "new_name": new_name, "folder": str(folder),
            "expected_tree_sha256": digest,
        }
        self.plans_dir.mkdir(parents=True, exist_ok=True)
        with (self.plans_dir / (plan_id + ".json")).open("x", encoding="utf-8") as out:
            json.dump(record, out, ensure_ascii=False)
        return {
            **record, "files": rows, "file_count": len(rows),
            "total_bytes": sum(r["bytes"] for r in rows),
            "message": "Preview file list before confirming. Git state is unchanged.",
        }

    def restore(self, trash_id: str, confirm: bool = False) -> dict:
        """Restore an archived Skill only if its original target is still absent."""
        if confirm is not True:
            raise PermissionError("confirm=true required to restore archived Skill")
        if not isinstance(trash_id, str) or not DRAFT_ID_RE.fullmatch(trash_id):
            raise ValueError("invalid trash ID")
        plan_path = self.plans_dir / (trash_id + ".json")
        if plan_path.is_symlink():
            raise PermissionError("lifecycle plan symlinks are forbidden")
        record = json.loads(plan_path.read_text(encoding="utf-8"))
        if record.get("plan_id") != trash_id or record.get("action") != "delete":
            raise ValueError("trash ID does not refer to a deleted Skill")
        source_id, name = record["source_id"], record["name"]
        target = self.author._destination(source_id, name).parent
        if str(target) != record["folder"]:
            raise RuntimeError("source path changed since deletion")
        archive = self.trash_dir / trash_id
        _, digest = self._inventory(archive)
        if digest != record["expected_tree_sha256"]:
            raise RuntimeError("archived Skill contents changed")
        if target.exists() or target.is_symlink():
            raise FileExistsError("cannot restore over an existing Skill folder")
        os.rename(archive, target)
        self.manager.states.forget_skill(source_id, name)
        synced = self.manager.source_sync(source_id)["results"][source_id]
        return {
            "status": "restored", "source_id": source_id, "name": name,
            "sync": synced, "git_committed": False, "git_pushed": False,
            "next_step": "Review Git state and commit restored files if appropriate.",
        }

    def apply(self, plan_id: str, expected_tree_sha256: str,
              confirm: bool = False) -> dict:
        if confirm is not True:
            raise PermissionError("confirm=true required for Skill lifecycle mutation")
        if not isinstance(plan_id, str) or not DRAFT_ID_RE.fullmatch(plan_id):
            raise ValueError("invalid plan ID")
        if not isinstance(expected_tree_sha256, str) or not HASH_RE.fullmatch(expected_tree_sha256):
            raise ValueError("invalid tree SHA")
        plan_path = self.plans_dir / (plan_id + ".json")
        if plan_path.is_symlink():
            raise PermissionError("plan symlinks are forbidden")
        record = json.loads(plan_path.read_text(encoding="utf-8"))
        if record["plan_id"] != plan_id or record["action"] not in ("delete", "rename"):
            raise RuntimeError("invalid lifecycle plan")
        source_id, name, action = record["source_id"], record["name"], record["action"]
        target = self.author._destination(source_id, name)
        folder = target.parent
        if str(folder) != record["folder"]:
            raise RuntimeError("Skill folder changed after planning")
        if expected_tree_sha256 != record["expected_tree_sha256"]:
            raise ValueError("reviewed tree version mismatch")
        _, current = self._inventory(folder)
        if current != expected_tree_sha256:
            raise RuntimeError("Skill tree changed after preview")
        if action == "delete":
            # Move to a per-draft archive without deleting the contents.
            self.trash_dir.mkdir(parents=True, exist_ok=True)
            destination = self.trash_dir / plan_id
            if destination.exists() or destination.is_symlink():
                raise FileExistsError("lifecycle trash ID already exists")
            os.rename(folder, destination)
            # Prevent stale cached instructions being used until re-sync succeeds.
            self.manager.states.set_enabled(source_id, name, False)
            result = {"status": "archived", "trash_id": plan_id,
                      "archive_path": str(destination)}
        else:
            new_name = record["new_name"]
            destination = self.author._destination(source_id, new_name).parent
            if destination.exists():
                raise FileExistsError("new Skill name already exists")
            updated = self._renamed_skill(target.read_text(encoding="utf-8"), name, new_name)
            os.rename(folder, destination)
            try:
                new_skill = destination / "SKILL.md"
                fd, tmp = tempfile.mkstemp(prefix=".skill-rename-", suffix=".tmp",
                                            dir=destination)
                try:
                    with os.fdopen(fd, "w", encoding="utf-8") as stream:
                        stream.write(updated)
                        stream.flush()
                        os.fsync(stream.fileno())
                    os.replace(tmp, new_skill)
                finally:
                    if os.path.exists(tmp):
                        os.unlink(tmp)
            except Exception:
                os.rename(destination, folder)
                raise
            self.manager.states.rename(source_id, name, new_name)
            # Keep the old cached entry hidden until it is replaced by the sync.
            self.manager.states.set_enabled(source_id, name, False)
            result = {"status": "renamed", "new_name": new_name}
        synced = self.manager.source_sync(source_id)["results"][source_id]
        if synced["status"] in ("updated", "unchanged"):
            self.manager.states.forget_skill(source_id, name)
        return {
            **result, "source_id": source_id, "name": name,
            "sync": synced,
            "git_committed": False, "git_pushed": False,
            "next_step": "Review governed PLA Git changes and commit/push if approved.",
        }
