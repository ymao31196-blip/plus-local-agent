"""Reviewed, byte-preserving first-publication transfer between local Skill Sources.

No Git, network or subprocess calls. The user separately provisions a clone and
uses PLA's governed Git stage/commit/push after this copy is reviewed.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import uuid
from pathlib import Path

from .authoring import DRAFT_ID_RE, HASH_RE
from .local_source import LocalDirectorySource
from .parser import NAME_RE, parse_skill

MAX_FILES = 64  # Matches PLA governed Git stage/commit per-operation path limit.
MAX_TOTAL_BYTES = 16 * 1024 * 1024
MAX_FILE_BYTES = 4 * 1024 * 1024


class SkillPublication:
    def __init__(self, manager, write_roots=None):
        self.manager = manager
        if write_roots is None:
            configured = os.environ.get("SKILL_LIBRARY_WRITE_ROOTS", "")
            write_roots = tuple(Path(x) for x in configured.split(os.pathsep) if x)
        self.write_roots = tuple(Path(p) for p in write_roots)
        self.plan_dir = self.manager.data_dir / "publication-plans"

    def _root(self, source_id: str, *, writable: bool = False) -> Path:
        config = self.manager.registry.get(source_id)
        if config.kind != "local" or not config.enabled:
            raise PermissionError("publication requires an enabled local Skill Source")
        folder = Path(config.location)
        if config.subdir != ".":
            folder = folder.joinpath(*config.subdir.split("/"))
        root = LocalDirectorySource(folder, self.manager.local_roots)._approved_path()
        if writable:
            if not self.write_roots:
                raise PermissionError("publication writing is disabled")
            approved_roots = (p.resolve(strict=True) for p in self.write_roots)
            if not any(root == allowed or allowed in root.parents for allowed in approved_roots):
                raise PermissionError("destination outside approved writable roots")
            marker = root / ".git"
            if marker.is_symlink() or not marker.is_dir() or not marker.resolve(strict=True).is_relative_to(root):
                raise ValueError("destination must be a checked-out Git repository with a contained .git directory")
            skills_dir = root / "skills"
            if skills_dir.exists() or skills_dir.is_symlink():
                raise FileExistsError("destination skills/ already exists; refusing overwrite")
        return root

    def _inventory(self, source_id: str, source_root: Path,
                   include_disabled: bool) -> tuple[list[dict], list[str], str]:
        skills_dir = source_root / "skills"
        if skills_dir.is_symlink() or not skills_dir.is_dir():
            raise ValueError("source must have ordinary skills/ directory")
        files: list[dict] = []
        excluded: list[str] = []
        total_bytes = 0
        for folder in sorted(skills_dir.iterdir(), key=lambda p: p.name):
            if (folder.is_symlink() or not folder.is_dir()
                    or not folder.resolve(strict=True).is_relative_to(source_root)
                    or not NAME_RE.fullmatch(folder.name)):
                raise PermissionError("noncanonical or escaped Skill folder forbidden")
            if not self.manager.states.enabled(source_id, folder.name) and not include_disabled:
                excluded.append(folder.name)
                continue
            entry = folder / "SKILL.md"
            if entry.is_symlink() or not entry.is_file():
                raise ValueError(f"missing ordinary SKILL.md: {folder.name}")
            parsed = parse_skill(entry.read_text(encoding="utf-8"),
                                 f"skills/{folder.name}/SKILL.md", allow_extensions=True)
            if parsed.name != folder.name:
                raise ValueError(f"Skill name mismatch: {folder.name}")
            for directory, dirs, names in os.walk(folder, followlinks=False):
                parent = Path(directory)
                if parent.is_symlink() or not parent.resolve(strict=True).is_relative_to(source_root):
                    raise PermissionError("escaped or symlink directory forbidden")
                for name in dirs:
                    if (name.startswith(".") or (parent / name).is_symlink()
                            or not (parent / name).resolve(strict=True).is_relative_to(source_root)):
                        raise PermissionError("hidden or escaped resource directory forbidden")
                for name in sorted(names):
                    current = parent / name
                    if (name.startswith(".") or current.is_symlink() or not current.is_file()
                            or not current.resolve(strict=True).is_relative_to(source_root)):
                        raise PermissionError("hidden, escaped or non-regular file forbidden")
                    size = current.stat().st_size
                    if size > MAX_FILE_BYTES:
                        raise ValueError("Skill resource file exceeds publication size limit")
                    total_bytes += size
                    if len(files) >= MAX_FILES or total_bytes > MAX_TOTAL_BYTES:
                        raise ValueError("Skill publication exceeds file/count limits")
                    files.append({
                        "path": current.relative_to(source_root).as_posix(),
                        "sha256": hashlib.sha256(current.read_bytes()).hexdigest(),
                        "bytes": size,
                    })
        files.sort(key=lambda x: x["path"])
        if not files:
            raise ValueError("no enabled Skills to publish")
        digest = hashlib.sha256(json.dumps(files, sort_keys=True).encode("utf-8")).hexdigest()
        return files, excluded, digest

    def prepare(self, source_id: str, destination_source_id: str,
                include_disabled: bool = False) -> dict:
        if type(include_disabled) is not bool:
            raise ValueError("include_disabled must be boolean")
        if source_id == destination_source_id:
            raise ValueError("source and destination must differ")
        src = self._root(source_id)
        dest = self._root(destination_source_id, writable=True)
        if src == dest or src in dest.parents or dest in src.parents:
            raise ValueError("source and destination directories must not overlap")
        files, excluded, digest = self._inventory(source_id, src, include_disabled)
        plan_id = uuid.uuid4().hex
        record = {
            "plan_id": plan_id, "source_id": source_id,
            "destination_source_id": destination_source_id,
            "source_path": str(src), "destination_path": str(dest),
            "include_disabled": include_disabled,
            "excluded_disabled": excluded,
            "files": files, "expected_tree_sha256": digest,
        }
        self.plan_dir.mkdir(parents=True, exist_ok=True)
        with (self.plan_dir / f"{plan_id}.json").open("x", encoding="utf-8") as fp:
            json.dump(record, fp, ensure_ascii=False)
        return {
            **record, "file_count": len(files),
            "total_bytes": sum(row["bytes"] for row in files),
            "message": "Review every file before confirming transfer; no files were copied or pushed.",
        }

    def apply(self, plan_id: str, expected_tree_sha256: str,
              *, confirm: bool = False) -> dict:
        if confirm is not True:
            raise PermissionError("confirm=true required for Skill publication copy")
        if not isinstance(plan_id, str) or not DRAFT_ID_RE.fullmatch(plan_id):
            raise ValueError("invalid publication plan ID")
        if not isinstance(expected_tree_sha256, str) or not HASH_RE.fullmatch(expected_tree_sha256):
            raise ValueError("invalid tree SHA")
        plan_path = self.plan_dir / f"{plan_id}.json"
        if plan_path.is_symlink():
            raise PermissionError("publication plan symlinks forbidden")
        plan = json.loads(plan_path.read_text(encoding="utf-8"))
        if plan.get("plan_id") != plan_id or plan.get("expected_tree_sha256") != expected_tree_sha256:
            raise ValueError("publication plan identity or expected hash mismatch")
        source_id = plan["source_id"]
        dest_id = plan["destination_source_id"]
        src = self._root(source_id)
        dest = self._root(dest_id, writable=True)
        if src == dest or src in dest.parents or dest in src.parents:
            raise ValueError("source and destination directories must not overlap")
        if str(src) != plan["source_path"] or str(dest) != plan["destination_path"]:
            raise RuntimeError("publication source or destination changed")
        current, _, digest = self._inventory(source_id, src, plan["include_disabled"])
        if current != plan["files"] or digest != expected_tree_sha256:
            raise RuntimeError("Skill files changed after publication preview")

        staging = Path(tempfile.mkdtemp(prefix=".skill-publication-", dir=dest))
        try:
            for item in current:
                original = src.joinpath(*item["path"].split("/"))
                copied = staging.joinpath(*item["path"].split("/"))
                copied.parent.mkdir(parents=True, exist_ok=True)
                if original.is_symlink() or not original.is_file():
                    raise RuntimeError("source changed during copy")
                data = original.read_bytes()
                if hashlib.sha256(data).hexdigest() != item["sha256"]:
                    raise RuntimeError("source hash changed during copy")
                with copied.open("xb") as fp:
                    fp.write(data)
                    fp.flush()
                    os.fsync(fp.fileno())
            # Refuse changes to the source between preflight and publication.
            if self._inventory(source_id, src, plan["include_disabled"])[2] != digest:
                raise RuntimeError("source changed during publication")
            target_skills = dest / "skills"
            if target_skills.exists() or target_skills.is_symlink():
                raise FileExistsError("destination skills/ appeared during publication")
            os.rename(staging / "skills", target_skills)
        finally:
            shutil.rmtree(staging, ignore_errors=True)

        synced = self.manager.source_sync(dest_id)["results"][dest_id]
        return {
            "status": "copied", "source_id": source_id,
            "destination_source_id": dest_id, "file_count": len(current),
            "files": current, "tree_sha256": digest, "sync": synced,
            "git_committed": False, "git_pushed": False,
            "next_step": "Review new files, stage exact paths with PLA governed Git, commit, then obtain separate PUSH authorization.",
        }
