"""Explicit, two-step authoring of SKILL.md in approved local sources.

This module never invokes Git or executes Skill scripts. Read-only source roots
do not imply write permission; an independent administrator allowlist is needed.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import uuid
from pathlib import Path

from .local_source import LocalDirectorySource
from .parser import NAME_RE, parse_skill

DRAFT_ID_RE = re.compile(r"^[0-9a-f]{32}$")
HASH_RE = re.compile(r"^[0-9a-f]{64}$")
ABSENT = "absent"


class SkillAuthor:
    def __init__(self, manager, write_roots=None):
        self.manager = manager
        if write_roots is None:
            configured = os.environ.get("SKILL_LIBRARY_WRITE_ROOTS", "")
            write_roots = [Path(p) for p in configured.split(os.pathsep) if p]
        self.write_roots = tuple(Path(p) for p in write_roots)
        self.drafts_dir = self.manager.data_dir / "drafts"

    def _destination(self, source_id: str, name: str) -> Path:
        if not NAME_RE.fullmatch(name):
            raise ValueError("invalid Skill name")
        source = self.manager.registry.get(source_id)
        if not source.enabled or source.kind != "local":
            raise PermissionError("Skill authoring requires an enabled local source")
        directory = Path(source.location)
        if source.subdir != ".":
            directory = directory.joinpath(*source.subdir.split("/"))
        root = LocalDirectorySource(directory, self.manager.local_roots)._approved_path()
        if not self.write_roots:
            raise PermissionError("writing disabled: SKILL_LIBRARY_WRITE_ROOTS is not set")
        if not any(root == approved or approved in root.parents
                   for approved in (p.resolve(strict=True) for p in self.write_roots)):
            raise PermissionError("source is outside SKILL_LIBRARY_WRITE_ROOTS")
        target_dir = root / "skills" / name
        for parent in (root / "skills", target_dir):
            if parent.is_symlink():
                raise PermissionError("symlink Skill paths are forbidden")
            if parent.exists() and not parent.is_dir():
                raise ValueError("Skill path contains a non-directory")
        target = target_dir / "SKILL.md"
        if target.is_symlink():
            raise PermissionError("symlink Skill files are forbidden")
        if target.exists() and not target.is_file():
            raise ValueError("Skill target is not a regular file")
        return target

    @staticmethod
    def _current_sha(target: Path) -> str:
        if not target.exists():
            return ABSENT
        if target.is_symlink() or not target.is_file():
            raise PermissionError("symlink or non-regular Skill target is forbidden")
        if target.stat().st_size > 64 * 1024:
            raise ValueError("existing SKILL.md exceeds size limit")
        return hashlib.sha256(target.read_bytes()).hexdigest()

    def prepare(self, source_id: str, name: str, content: str) -> dict:
        """Validate a candidate and persist an immutable draft; do not edit the source."""
        if not isinstance(content, str):
            raise ValueError("Skill content must be UTF-8 text")
        parsed = parse_skill(content, f"skills/{name}/SKILL.md", allow_extensions=True)
        if parsed.name != name:
            raise ValueError("Skill name does not match content")
        target = self._destination(source_id, name)
        expected = self._current_sha(target)
        # An existing malformed SKILL.md may also be repaired. Its old SHA is
        # still required when the reviewed draft is applied.
        draft_id = uuid.uuid4().hex
        record = {
            "draft_id": draft_id,
            "source_id": source_id,
            "name": name,
            "content": parsed.content,
            "sha256": parsed.sha256,
            "expected_current_sha256": expected,
            "target": str(target),
        }
        self.drafts_dir.mkdir(parents=True, exist_ok=True)
        # Never reuse caller-provided paths or overwrite existing draft records.
        with (self.drafts_dir / (draft_id + ".json")).open("x", encoding="utf-8") as fp:
            json.dump(record, fp, ensure_ascii=False)
        return {
            **record,
            "action": "create" if expected == ABSENT else "replace",
            "message": "Preview and approve the content before applying. No Git operations were performed.",
        }

    def apply(self, draft_id: str, expected_current_sha256: str, *,
              confirm: bool = False) -> dict:
        """Apply a reviewed draft with path and optimistic-concurrency checks."""
        if confirm is not True:
            raise PermissionError("confirm=true is required to apply a Skill draft")
        if not isinstance(draft_id, str) or not DRAFT_ID_RE.fullmatch(draft_id):
            raise ValueError("invalid draft ID")
        if not isinstance(expected_current_sha256, str) or (
            expected_current_sha256 != ABSENT
            and not HASH_RE.fullmatch(expected_current_sha256)
        ):
            raise ValueError("expected_current_sha256 must be 'absent' or SHA-256")
        draft_path = self.drafts_dir / (draft_id + ".json")
        if draft_path.is_symlink():
            raise PermissionError("draft symlinks are forbidden")
        record = json.loads(draft_path.read_text(encoding="utf-8"))
        if record.get("draft_id") != draft_id:
            raise RuntimeError("draft identity mismatch")
        source_id, name, content = record["source_id"], record["name"], record["content"]
        parsed = parse_skill(content, f"skills/{name}/SKILL.md", allow_extensions=True)
        if parsed.sha256 != record["sha256"]:
            raise RuntimeError("draft content integrity mismatch")
        target = self._destination(source_id, name)
        if str(target) != record["target"]:
            raise RuntimeError("source path changed since drafting")
        if expected_current_sha256 != record["expected_current_sha256"]:
            raise ValueError("expected file version does not match reviewed draft")
        if self._current_sha(target) != expected_current_sha256:
            raise RuntimeError("source content changed since drafting")
        target.parent.mkdir(parents=True, exist_ok=True)
        if (target.parent.parent.is_symlink() or target.parent.is_symlink()
                or target.is_symlink()):
            raise PermissionError("symlink target appeared before write")
        fd, temp_name = tempfile.mkstemp(prefix=".skill-draft-", suffix=".tmp",
                                         dir=target.parent)
        try:
            with os.fdopen(fd, "wb") as fp:
                fp.write(content.encode("utf-8"))
                fp.flush()
                os.fsync(fp.fileno())
            if expected_current_sha256 == ABSENT:
                os.link(temp_name, target)  # fails if someone created the file
            else:
                if self._current_sha(target) != expected_current_sha256:
                    raise RuntimeError("source content changed during write")
                os.replace(temp_name, target)
            return {
                "status": "applied",
                "source_id": source_id,
                "name": name,
                "path": str(target),
                "sha256": parsed.sha256,
                "git_committed": False,
                "git_pushed": False,
                "next_step": "Use PLA's governed Git stage/commit/push after review; then source_sync.",
            }
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)
