from __future__ import annotations

import base64
import hashlib
import json
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol
from urllib.parse import quote
from urllib.request import Request, urlopen


class SkillSource(Protocol):
    def get_head_sha(self) -> str: ...
    def list_files(self, ref: str) -> list[str]: ...
    def read_text(self, path: str, ref: str) -> str: ...


@dataclass
class GitHubSource:
    repo: str
    branch: str = "main"
    token: str | None = None
    api_base: str = "https://api.github.com"

    @classmethod
    def from_env(cls) -> "GitHubSource":
        repo = os.getenv("SKILL_LIBRARY_REPO", "").strip()
        if not repo or "/" not in repo:
            raise ValueError("SKILL_LIBRARY_REPO must be set to owner/repo")
        return cls(
            repo=repo,
            branch=os.getenv("SKILL_LIBRARY_BRANCH", "main").strip() or "main",
            token=os.getenv("SKILL_LIBRARY_GITHUB_TOKEN") or None,
        )

    def _json(self, path: str) -> dict:
        request = Request(
            f"{self.api_base}{path}",
            headers={
                "Accept": "application/vnd.github+json",
                "User-Agent": "chatgpt-skill-library/0.1",
                **({"Authorization": f"Bearer {self.token}"} if self.token else {}),
            },
        )
        with urlopen(request, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))

    def get_head_sha(self) -> str:
        payload = self._json(
            f"/repos/{self.repo}/commits/{quote(self.branch, safe='')}"
        )
        return str(payload["sha"])

    def list_files(self, ref: str) -> list[str]:
        payload = self._json(
            f"/repos/{self.repo}/git/trees/{quote(ref, safe='')}?recursive=1"
        )
        if payload.get("truncated"):
            raise RuntimeError("GitHub tree response was truncated")
        return [
            item["path"]
            for item in payload.get("tree", [])
            if item.get("type") == "blob" and isinstance(item.get("path"), str)
        ]

    def read_text(self, path: str, ref: str) -> str:
        payload = self._json(
            f"/repos/{self.repo}/contents/{quote(path, safe='/')}?ref={quote(ref, safe='')}"
        )
        if payload.get("encoding") != "base64":
            raise RuntimeError(f"unsupported GitHub content encoding for {path}")
        raw = base64.b64decode(payload["content"], validate=False)
        return raw.decode("utf-8")


@dataclass
class GitCliSource:
    repo: str
    branch: str = "main"
    mirror_dir: Path | None = None

    @classmethod
    def from_env(cls) -> "GitCliSource":
        repo = os.getenv("SKILL_LIBRARY_REPO", "").strip()
        if not repo:
            raise ValueError("SKILL_LIBRARY_REPO must be set")
        mirror = os.getenv("SKILL_LIBRARY_GIT_MIRROR", "").strip()
        return cls(
            repo=repo,
            branch=os.getenv("SKILL_LIBRARY_BRANCH", "main").strip() or "main",
            mirror_dir=Path(mirror) if mirror else None,
        )

    @property
    def repo_url(self) -> str:
        if "://" in self.repo or self.repo.startswith("git@") or self.repo.startswith("file:"):
            return self.repo
        path = Path(self.repo)
        if path.is_absolute() or self.repo.startswith("."):
            return str(path)
        if self.repo.endswith(".git") and ("/" not in self.repo or "\\" in self.repo):
            return self.repo
        if "/" not in self.repo:
            raise ValueError("Git repository must be owner/repo, URL, or local path")
        return f"https://github.com/{self.repo}.git"

    def _mirror_path(self) -> Path:
        if self.mirror_dir is not None:
            return self.mirror_dir
        configured = os.getenv("SKILL_LIBRARY_DATA_DIR", "").strip()
        base = (
            Path(configured)
            if configured
            else Path.home() / ".cache" / "chatgpt-skill-library"
        )
        key = hashlib.sha256(self.repo_url.encode("utf-8")).hexdigest()[:16]
        return base / "git-source" / f"{key}.git"

    def _run(self, *args: str, binary: bool = False) -> str | bytes:
        command = ["git", *args]
        result = subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=not binary,
            encoding=None if binary else "utf-8",
            errors=None if binary else "strict",
            timeout=90,
            env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
        )
        return result.stdout

    def _ensure_mirror(self) -> Path:
        mirror = self._mirror_path()
        if not mirror.exists():
            mirror.parent.mkdir(parents=True, exist_ok=True)
            self._run("clone", "--mirror", self.repo_url, str(mirror))
        else:
            existing = str(
                self._run("--git-dir", str(mirror), "remote", "get-url", "origin")
            ).strip()
            if existing != self.repo_url:
                raise RuntimeError(
                    f"Git mirror remote mismatch: expected {self.repo_url}, found {existing}"
                )
        return mirror

    def _fetch(self) -> Path:
        mirror = self._ensure_mirror()
        self._run("--git-dir", str(mirror), "fetch", "--prune", "origin")
        return mirror

    def get_head_sha(self) -> str:
        mirror = self._fetch()
        return str(
            self._run(
                "--git-dir",
                str(mirror),
                "rev-parse",
                f"refs/heads/{self.branch}",
            )
        ).strip()

    def list_files(self, ref: str) -> list[str]:
        mirror = self._ensure_mirror()
        output = str(
            self._run("--git-dir", str(mirror), "ls-tree", "-r", "--name-only", ref)
        )
        return [line for line in output.splitlines() if line]

    def read_text(self, path: str, ref: str) -> str:
        mirror = self._ensure_mirror()
        raw = self._run(
            "--git-dir",
            str(mirror),
            "show",
            f"{ref}:{path}",
            binary=True,
        )
        assert isinstance(raw, bytes)
        return raw.decode("utf-8")


def source_from_env() -> SkillSource:
    transport = os.getenv("SKILL_LIBRARY_TRANSPORT", "").strip().lower()
    if not transport:
        transport = "github" if os.getenv("SKILL_LIBRARY_GITHUB_TOKEN") else "git"
    if transport == "git":
        return GitCliSource.from_env()
    if transport == "github":
        return GitHubSource.from_env()
    raise ValueError("SKILL_LIBRARY_TRANSPORT must be 'git' or 'github'")
