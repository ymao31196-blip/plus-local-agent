from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Any

import yaml

NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
MAX_SKILL_BYTES = 64 * 1024
ALLOWED_FRONTMATTER = {
    "name",
    "description",
    "license",
    "compatibility",
    "metadata",
    "allowed-tools",
}


class SkillValidationError(ValueError):
    pass


@dataclass(frozen=True)
class ParsedSkill:
    name: str
    description: str
    metadata: dict[str, str]
    content: str
    source_path: str
    sha256: str

    @property
    def version(self) -> str | None:
        return self.metadata.get("version")


def parse_skill(text: str, source_path: str, *, allow_extensions: bool = False) -> ParsedSkill:
    # Read-only sources may preserve Windows CRLF; normalize before parsing.
    text = text.removeprefix("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    encoded = text.encode("utf-8")
    if len(encoded) > MAX_SKILL_BYTES:
        raise SkillValidationError(f"SKILL.md exceeds {MAX_SKILL_BYTES} bytes")
    if not text.startswith("---\n"):
        raise SkillValidationError("SKILL.md must begin with YAML frontmatter")

    closing = text.find("\n---\n", 4)
    if closing < 0:
        raise SkillValidationError("SKILL.md frontmatter is not closed")
    raw_frontmatter = text[4:closing]
    body = text[closing + 5:]

    try:
        data: Any = yaml.safe_load(raw_frontmatter)
    except yaml.YAMLError as exc:
        raise SkillValidationError(f"invalid YAML frontmatter: {exc}") from exc

    if not isinstance(data, dict):
        raise SkillValidationError("frontmatter must be a YAML mapping")

    unknown = set(data) - ALLOWED_FRONTMATTER
    if unknown and not allow_extensions:
        raise SkillValidationError(
            "unsupported frontmatter fields: " + ", ".join(sorted(unknown))
        )

    name = data.get("name")
    description = data.get("description")
    if not isinstance(name, str) or not (1 <= len(name) <= 64) or not NAME_RE.fullmatch(name):
        raise SkillValidationError(
            "name must be 1-64 chars using lowercase letters, digits, and single hyphens"
        )
    if not isinstance(description, str) or not (1 <= len(description) <= 1024):
        raise SkillValidationError("description must be a non-empty string <= 1024 chars")

    path = PurePosixPath(source_path)
    if path.name != "SKILL.md" or path.parent.name != name:
        raise SkillValidationError("skill name must match its parent directory")

    compatibility = data.get("compatibility")
    if compatibility is not None:
        if not isinstance(compatibility, str) or not (1 <= len(compatibility) <= 500):
            raise SkillValidationError("compatibility must be a string <= 500 chars")

    allowed_tools = data.get("allowed-tools")
    if allowed_tools is not None and not isinstance(allowed_tools, str):
        raise SkillValidationError("allowed-tools must be a string")

    metadata = data.get("metadata") or {}
    if not isinstance(metadata, dict):
        raise SkillValidationError("metadata must be a mapping")
    normalized_metadata: dict[str, str] = {}
    for key, value in metadata.items():
        if not isinstance(key, str) or not isinstance(value, str):
            raise SkillValidationError("metadata must map string keys to string values")
        normalized_metadata[key] = value

    if allow_extensions:
        # Common non-standard fields are advisory metadata, never tool permissions.
        for field in ("version", "tags"):
            value = data.get(field)
            if isinstance(value, str):
                normalized_metadata.setdefault(field, value)
            elif field == "version" and isinstance(value, (int, float)) and not isinstance(value, bool):
                normalized_metadata.setdefault(field, str(value))
            elif field == "tags" and isinstance(value, list) and all(isinstance(item, str) for item in value):
                normalized_metadata.setdefault(field, ",".join(value))

    if not body.strip():
        raise SkillValidationError("SKILL.md body must not be empty")

    return ParsedSkill(
        name=name,
        description=description.strip(),
        metadata=normalized_metadata,
        content=text,
        source_path=source_path,
        sha256=hashlib.sha256(encoded).hexdigest(),
    )
